from typing import List, Optional, Union
import json
import os
import boto3
class ParameterInfo():
    name:str
    dataType:str
    value:Optional[Union[str, float, int]] = None
    hot_reader_arn: Optional[str] = None
    region: Optional[str] = None
    component_name: Optional[str] = None
    property_name: Optional[str] = None
    workspace_id: Optional[str] = None
    entity_id: Optional[str] = None

    @staticmethod
    def parseInfo(data):
        param = ParameterInfo()
        param.name = data["name"]
        param.hot_reader_arn = data.get("hot_reader_arn", None)
        param.region = data.get("region", None)
        param.dataType = data.get("dataType", None)
        param.component_name = data.get("component_name", None)
        param.property_name = data.get("property_name", None)
        param.workspace_id = data.get("workspace_id", None)
        param.entity_id = data.get("entity_id", None)
        param.strategy_name = data.get("strategy_name", None)
        return param

    def fetch_value(self):
        if self.hot_reader_arn:
            lambda_client = boto3.client("lambda", region_name=self.region)
        
            payload = {
            "workspaceId": self.workspace_id,
            "entityId": self.entity_id,
            "componentName": self.component_name,
            "selectedProperties": [self.property_name],
            "properties": {
                self.property_name: {
                    "definition": {
                        "dataType": {"type": self.dataType}
                    }
                }
            }
        }
        
            response = lambda_client.invoke(
                FunctionName=self.hot_reader_arn,
                InvocationType="RequestResponse",
                Payload=json.dumps(payload).encode("utf-8")
            )
        
            result = json.loads(response["Payload"].read())
            prop = result["propertyValues"].get(self.property_name)
            if prop:
                value_dict = prop["propertyValue"]["value"]
                self.value = list(value_dict.values())[0]
                return
        print("Warning: No value fetched for parameter '{}'".format(self.name))
        self.value = None

class Parameters:

    def __init__(self, strategy_name: str):
        self.strategy_name = strategy_name
        self.parameterInfos: dict[str, dict[str, list[ParameterInfo]]] = {}

    def parse_parameters(self, param_info:dict[List[ParameterInfo]]):
        for p in param_info[self.strategy_name]:
            param = ParameterInfo.parseInfo(p)
            if param.workspace_id not in self.parameterInfos:
                self.parameterInfos[param.workspace_id] = {}
            if param.strategy_name not in self.parameterInfos[param.workspace_id]:
                self.parameterInfos[param.workspace_id][param.strategy_name] = []
            self.parameterInfos[param.workspace_id][param.strategy_name].append(param)
    
    def fetch_all_values(self):
        for workspace_id, strategies in self.parameterInfos.items():
            for strategy_name , params in strategies.items():
                for param in params:
                    param.fetch_value()
    
    def returnValues(self):
        res = {}
        for workspace_id, strategies in self.parameterInfos.items():
            res[workspace_id] = {}
            for strategy_name, params in strategies.items():
                res[workspace_id][strategy_name] = {param.name: param.value for param in params}
        return res
    

PARAMETER_INFO = json.loads(os.environ.get("PARAMETERS", None))


def lambda_handler(event, context):

    print("Received event:", event)
    strategy_name = event["e"]["action"]["functionName"]

    parameters = Parameters(strategy_name)
    parameters.parse_parameters(PARAMETER_INFO)
    parameters.fetch_all_values()

    return {
        'statusCode': 200,
        'body': json.dumps(parameters.returnValues())
    }